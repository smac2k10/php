<?php
$conn=mysqli_connect("localhost","root","","project");
if(!$conn){
    echo"error";
}
?>
