<?php
 include "db.php";
 if(isset($_POST["submit"])){
  
    $username=$_POST["username"];
    $pwd=$_POST["pwd"];
    $qry="INSERT into user (username,pwd) values('$username','$pwd')";
    $result=mysqli_query($conn,$qry);
    if($result){
        echo "Login Successful";
        echo"<script>location.href='adminviewdata.php'</script>";
    }else{
        echo "Error in Login";
    }
 }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login Panel</title>
    <style>
        body{
            text-align:center;
        }
    </style>
</head>

<body>
    <h1>Welcome to Admin Login Portal</h1>

    <form method="post">
        <label for="username">Email: </label>
        <input type="email" placeholder="Enter your email" required><br>
        <label for="name">Password: </label>
        <input type="password" placeholder="Enter your password" required>
        <button type="submit" name="submit">Submit</button>
    </form>

</body>

</html>
