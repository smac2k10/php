<?php
 include "db.php";

 if(isset($_POST["submit"])){
    $fname=$_POST["fname"];
    $username=$_POST["username"];
    $pwd=$_POST["pwd"];
    $qry="INSERT into user (fname,username,pwd) values('$fname','$username','$pwd')";
    $result=mysqli_query($conn,$qry);
    if($result){
        echo "Registration Successful";
        echo"<script>location.href='view.php'</script>";
    }else{
        echo "Error in Creation";
    }
 }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration Page</title>
    <style>
        body{
            text-align:center;
        }
    </style>
</head>

<body>
    <h1 >Welcome to User Register Portal</h1>
    <form method="post">
        <label for="name">Name: </label>
        <input type="text" name="fname" placeholder="Enter your name" required><br>
        <label for="email">Email ID: </label>
        <input type="email" name="username" placeholder="Enter your email" required><br>
        <label for="password">Password: </label>
        <input type="password" name="pwd" placeholder="Enter your password" required><br>
        <button type="submit" name="submit">Register</button>
    </form>
    <h1>Already have an account? <a href="./login.php">Login Here</a></h1>
</body>

</html>