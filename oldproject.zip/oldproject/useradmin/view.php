<?php
include "db.php";
$qry="SELECT * from userdata";
$result=mysqli_query($conn,$qry);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User View Data</title>
    <style>
        body{
            text-align:center;
        }
    </style>
</head>
<body>
    <h1 style="text-align:center">User Data Portal</h1>
    <table width=100%;>
    <thead>
        <th>#</th>
        <th>Name</th>
        <th>Mobile</th>
        <th>Email</th>
        <th>Password</th>
    </thead>
    <tbody>
        <?php
        while($row=mysqli_fetch_assoc($result)){
            $id=$row['id'];
            $name=$row['name'];
            $mobile=$row['mobile'];
            $email=$row['email'];
            $pwd=$row['pwd'];
        ?>
        <td><?=$id?></td>
        <td><?=$name?></td>
        <td><?=$mobile?></td>
        <td><?=$email?></td>
        <td><?=$pwd?></td>

    </tbody>
    <?php
        }
    ?>
    </table>

    <h3>To Insert New Data <a href="insert.php">Click Here</a></h3>

    <a href="./login.php">Log Out</a>
</body>
</html>